import jakarta.servlet.*; 
import jakarta.servlet.http.*;
import java.io.*; 

public class Login extends HttpServlet {
    private String user1, pwd1, user2, pwd2, user3, pwd3, user4, pwd4;

    public void init(ServletConfig sc) throws ServletException {
        super.init(sc);
        user1 = sc.getInitParameter("username1"); 
        pwd1 = sc.getInitParameter("password1"); 
        user2 = sc.getInitParameter("username2"); 
        pwd2 = sc.getInitParameter("password2"); 
        user3 = sc.getInitParameter("username3"); 
        pwd3 = sc.getInitParameter("password3"); 
        user4 = sc.getInitParameter("username4"); 
        pwd4 = sc.getInitParameter("password4"); 
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html"); 
        PrintWriter out = res.getWriter(); 
        String user5 = req.getParameter("user"); 
        String pwd5 = req.getParameter("pwd"); 

        if ((user5.equals(user1) && pwd5.equals(pwd1)) || 
            (user5.equals(user2) && pwd5.equals(pwd2)) || 
            (user5.equals(user3) && pwd5.equals(pwd3)) || 
            (user5.equals(user4) && pwd5.equals(pwd4))) {
            out.println("<p>Welcome, " + user5.toUpperCase() + "!</p>"); 
        } else {
            out.println("<p>You are not an authenticated user.</p>"); 
        }
    }
}
